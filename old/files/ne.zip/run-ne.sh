#!/bin/bash

java -cp ./lib/core.jar:./lib/interfascia.jar:./lib/jaxb-api.jar:./lib/activation.jar:./lib/jaxb-impl.jar:./lib/jsr173_1.0_api.jar:./lib/ms.jar:./lib/ne.jar edu.uci.ics.mondego.ne.NeRun